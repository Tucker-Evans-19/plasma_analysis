import setuptools
setuptools.setup(
    name = "plasma_analysis", 
    version = "0.1.0", 
    description = "Plasma scripts", 
    long_description = "", 
    packages = setuptools.find_packages()
)


